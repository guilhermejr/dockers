// --- Fecha o canvas ---
function fecharCanvas(idCanvas) {
    const offcanvasElement = document.getElementById(idCanvas);
    const bsOffcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement);
    if (bsOffcanvas) {
      bsOffcanvas.hide();
    }
}

// --- Abre o modal de Fale Sobre o APP ---
function abrirModal(idCanvas) {
    fecharCanvas(idCanvas);
    const myModal = new bootstrap.Modal(document.getElementById('modalFaleSobre'));
    myModal.show();
}

// --- Abre site em janela extarna ---
function abrirSiteItau(idCanvas) {
    fecharCanvas(idCanvas);
    window.open('https://www.itau.com.br', '_blank');
}

// --- Adiciona e remove css para manter botão "ativo" durante uso ---
// Fale Sobre o APP 
const myOffcanvasFaleSobre = document.getElementById('offcanvasFaleSobre')
myOffcanvasFaleSobre.addEventListener('show.bs.offcanvas', event => {
    const elemento = document.getElementById('linkFaleSobre');
    elemento.classList.add('botao-fundo-branco');
});
myOffcanvasFaleSobre.addEventListener('hide.bs.offcanvas', event => {
    const elemento = document.getElementById('linkFaleSobre');
    elemento.classList.remove('botao-fundo-branco');
});

// Dúvidas
const myOffcanvasduvidas = document.getElementById('offcanvasDuvidas')
myOffcanvasduvidas.addEventListener('show.bs.offcanvas', event => {
    const elemento = document.getElementById('linkDuvidas');
    elemento.classList.add('botao-fundo-branco');
});
myOffcanvasduvidas.addEventListener('hide.bs.offcanvas', event => {
    const elemento = document.getElementById('linkDuvidas');
    elemento.classList.remove('botao-fundo-branco');
});

// Calculadora
const myOffcanvasCalculadora = document.getElementById('offcanvasCalculadora')
myOffcanvasCalculadora.addEventListener('show.bs.offcanvas', event => {
    const elemento = document.getElementById('linkCalculadora');
    elemento.classList.add('botao-fundo-branco');
});
myOffcanvasCalculadora.addEventListener('hide.bs.offcanvas', event => {
    const elemento = document.getElementById('linkCalculadora');
    elemento.classList.remove('botao-fundo-branco');
});

// Central de Diagnósticos
const myOffcanvasDiagnostico = document.getElementById('offcanvasDiagnostico')
myOffcanvasDiagnostico.addEventListener('show.bs.offcanvas', event => {
    const elemento = document.getElementById('linkDiagnostico');
    elemento.classList.add('botao-fundo-branco');
});
myOffcanvasDiagnostico.addEventListener('hide.bs.offcanvas', event => {
    const elemento = document.getElementById('linkDiagnostico');
    elemento.classList.remove('botao-fundo-branco');
});

// Central de Notificação
const myOffcanvasNotificacao = document.getElementById('offcanvasNotificacao')
myOffcanvasNotificacao.addEventListener('show.bs.offcanvas', event => {
    const elemento = document.getElementById('linkNotificacao');
    elemento.classList.add('botao-fundo-branco');
});
myOffcanvasNotificacao.addEventListener('hide.bs.offcanvas', event => {
    const elemento = document.getElementById('linkNotificacao');
    elemento.classList.remove('botao-fundo-branco');
});


// --- Zoom ---
let zoomLevel = 1; // Nível inicial de zoom

function zoomIn() {
  zoomLevel += 0.05;
  updateIframeZoom();
}

function zoomOut() {
  if (zoomLevel > 0.3) { // Limitar o nível de zoom mínimo
    zoomLevel -= 0.05;
  }
  updateIframeZoom();
}

function updateIframeZoom() {
  const iframe = document.getElementById('iframe');
  iframe.style.transform = `scale(${zoomLevel})`;
  iframe.style.width = `${100 / zoomLevel}%`; // Ajusta a largura do iframe para evitar corte
  iframe.style.height = `${100 / zoomLevel}%`; // Ajusta a altura do iframe para evitar corte
  document.getElementById('zoom').textContent = `${(zoomLevel * 100).toFixed(0)}%`;
}